﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAOLayer
{
    class QuanLyGiaoVienDAO
    {
        public void SelectByID(string strWhere)
        {
            string s = "SELECT * FROM tblGiaoVien WHERE" + strWhere;
        }
        public void Insert(string strValues)
        {
            string s = "INSERT INTO tblGiaoVien Values" + strValues;
        }
        public void Update(string strSet, string strWhere)
        {
            string s = "UPDATE tblGiaoVien SET" + strSet + "WHERE" + strWhere;
        }
        public void Delete(string strWhere)
        {
            string s = "DELETE * FROM tblGiaoVien Where" + strWhere;
        }
    }
}
