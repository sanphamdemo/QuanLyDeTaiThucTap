﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAOLayer
{
    class QuanLyDeTaiDAO
    {
        public void SelectByID(string strWhere)
        {
            string s = "SELECT * FROM tblDetai WHERE" + strWhere;
        }
        public void Insert(string strValues)
        {
            string s = "INSERT INTO tblDetai Values" + strValues;
        }
        public void Update(string strSet,string strWhere)
        {
            string s = "UPDATE tblDetai SET" + strSet + "WHERE" + strWhere;
        }
        public void Delete(string strWhere)
        {
            string s = "DELETE * FROM tblDetai Where" + strWhere;
        }
    }
}
