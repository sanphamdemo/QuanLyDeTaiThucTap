﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    class QuanLyGiaoVien
    {
        string MaGV;
        string TenGV;
        string Trinhdo;
        public QuanLyGiaoVien()
        {
            this.MaGV = "";
            this.TenGV = "";
            this.Trinhdo = "";
        }
        public QuanLyGiaoVien(string magv,string tengv,string trinhdo)
        {
            this.MaGV = magv;
            this.TenGV = tengv;
            this.Trinhdo = trinhdo;
        }
        public string Trinhdo1 { get => Trinhdo; set => Trinhdo = value; }
        public string TenGV1 { get => TenGV; set => TenGV = value; }
        public string MaGV1 { get => MaGV; set => MaGV = value; }
    }
}
