﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    class QuanLyDeTai
    {
        string MaDeTai;
        string TenDeTai;
        string MaGV;
        public QuanLyDeTai()
        {
            this.MaDeTai = "";
            this.TenDeTai = "";
            this.MaGV = "";
        }
        public QuanLyDeTai(string madetai,string tendetai,string magv)
        {
            this.MaDeTai = madetai;
            this.TenDeTai = tendetai;
            this.MaGV = magv;
        }
        public string MaGV1 { get => MaGV; set => MaGV = value; }
        public string TenDeTai1 { get => TenDeTai; set => TenDeTai = value; }
        public string MaDeTai1 { get => MaDeTai; set => MaDeTai = value; }
    }
}
