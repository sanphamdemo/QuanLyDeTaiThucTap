﻿namespace QuanLyDeTai
{
    partial class frmQuanLyDeTai
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblqldt = new System.Windows.Forms.Label();
            this.lblmadetai = new System.Windows.Forms.Label();
            this.lbltendetai = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblTimKiem = new System.Windows.Forms.Label();
            this.txtmadetai = new System.Windows.Forms.TextBox();
            this.txttendetai = new System.Windows.Forms.TextBox();
            this.txtmagv = new System.Windows.Forms.TextBox();
            this.txttimkiem = new System.Windows.Forms.TextBox();
            this.dgvDeTai = new System.Windows.Forms.DataGridView();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnTimKiem = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnHuy = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeTai)).BeginInit();
            this.SuspendLayout();
            // 
            // lblqldt
            // 
            this.lblqldt.AutoSize = true;
            this.lblqldt.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblqldt.Location = new System.Drawing.Point(296, 31);
            this.lblqldt.Name = "lblqldt";
            this.lblqldt.Size = new System.Drawing.Size(261, 26);
            this.lblqldt.TabIndex = 0;
            this.lblqldt.Text = "QUẢN LÝ TÊN ĐỀ TÀI";
            // 
            // lblmadetai
            // 
            this.lblmadetai.AutoSize = true;
            this.lblmadetai.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmadetai.Location = new System.Drawing.Point(55, 102);
            this.lblmadetai.Name = "lblmadetai";
            this.lblmadetai.Size = new System.Drawing.Size(91, 19);
            this.lblmadetai.TabIndex = 1;
            this.lblmadetai.Text = "Mã Đề Tài:";
            // 
            // lbltendetai
            // 
            this.lbltendetai.AutoSize = true;
            this.lbltendetai.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltendetai.Location = new System.Drawing.Point(55, 174);
            this.lbltendetai.Name = "lbltendetai";
            this.lbltendetai.Size = new System.Drawing.Size(94, 19);
            this.lbltendetai.TabIndex = 2;
            this.lbltendetai.Text = "Tên Đề Tài:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(55, 232);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 19);
            this.label4.TabIndex = 3;
            this.label4.Text = "Mã Giáo Viên:";
            // 
            // lblTimKiem
            // 
            this.lblTimKiem.AutoSize = true;
            this.lblTimKiem.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimKiem.Location = new System.Drawing.Point(55, 299);
            this.lblTimKiem.Name = "lblTimKiem";
            this.lblTimKiem.Size = new System.Drawing.Size(93, 19);
            this.lblTimKiem.TabIndex = 4;
            this.lblTimKiem.Text = "Tìm  Kiếm:";
            // 
            // txtmadetai
            // 
            this.txtmadetai.Location = new System.Drawing.Point(171, 101);
            this.txtmadetai.Name = "txtmadetai";
            this.txtmadetai.Size = new System.Drawing.Size(177, 22);
            this.txtmadetai.TabIndex = 5;
            // 
            // txttendetai
            // 
            this.txttendetai.Location = new System.Drawing.Point(171, 173);
            this.txttendetai.Name = "txttendetai";
            this.txttendetai.Size = new System.Drawing.Size(177, 22);
            this.txttendetai.TabIndex = 5;
            // 
            // txtmagv
            // 
            this.txtmagv.Location = new System.Drawing.Point(171, 229);
            this.txtmagv.Name = "txtmagv";
            this.txtmagv.Size = new System.Drawing.Size(177, 22);
            this.txtmagv.TabIndex = 5;
            // 
            // txttimkiem
            // 
            this.txttimkiem.Location = new System.Drawing.Point(171, 299);
            this.txttimkiem.Name = "txttimkiem";
            this.txttimkiem.Size = new System.Drawing.Size(177, 22);
            this.txttimkiem.TabIndex = 5;
            // 
            // dgvDeTai
            // 
            this.dgvDeTai.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDeTai.Location = new System.Drawing.Point(393, 99);
            this.dgvDeTai.Name = "dgvDeTai";
            this.dgvDeTai.RowTemplate.Height = 24;
            this.dgvDeTai.Size = new System.Drawing.Size(428, 217);
            this.dgvDeTai.TabIndex = 6;
            // 
            // btnThem
            // 
            this.btnThem.Location = new System.Drawing.Point(171, 380);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(75, 30);
            this.btnThem.TabIndex = 7;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // btnTimKiem
            // 
            this.btnTimKiem.Location = new System.Drawing.Point(58, 380);
            this.btnTimKiem.Name = "btnTimKiem";
            this.btnTimKiem.Size = new System.Drawing.Size(75, 30);
            this.btnTimKiem.TabIndex = 7;
            this.btnTimKiem.Text = "Tìm Kiếm";
            this.btnTimKiem.UseVisualStyleBackColor = true;
            this.btnTimKiem.Click += new System.EventHandler(this.btnTimKiem_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.Location = new System.Drawing.Point(393, 380);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(75, 30);
            this.btnXoa.TabIndex = 7;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnSua
            // 
            this.btnSua.Location = new System.Drawing.Point(283, 380);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(75, 30);
            this.btnSua.TabIndex = 7;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnLuu
            // 
            this.btnLuu.Location = new System.Drawing.Point(506, 380);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(75, 30);
            this.btnLuu.TabIndex = 7;
            this.btnLuu.Text = "Lưu";
            this.btnLuu.UseVisualStyleBackColor = true;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // btnHuy
            // 
            this.btnHuy.Location = new System.Drawing.Point(617, 380);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(75, 30);
            this.btnHuy.TabIndex = 7;
            this.btnHuy.Text = "Hủy";
            this.btnHuy.UseVisualStyleBackColor = true;
            // 
            // btnThoat
            // 
            this.btnThoat.Location = new System.Drawing.Point(726, 380);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(75, 30);
            this.btnThoat.TabIndex = 7;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // frmQuanLyDeTai
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(876, 450);
            this.Controls.Add(this.btnTimKiem);
            this.Controls.Add(this.btnSua);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnHuy);
            this.Controls.Add(this.btnLuu);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.dgvDeTai);
            this.Controls.Add(this.txttimkiem);
            this.Controls.Add(this.txtmagv);
            this.Controls.Add(this.txttendetai);
            this.Controls.Add(this.txtmadetai);
            this.Controls.Add(this.lblTimKiem);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lbltendetai);
            this.Controls.Add(this.lblmadetai);
            this.Controls.Add(this.lblqldt);
            this.Name = "frmQuanLyDeTai";
            this.Text = "frmQuanLyDeTai";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmQuanLyDeTai_FormClosing);
            this.Load += new System.EventHandler(this.frmQuanLyDeTai_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDeTai)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblqldt;
        private System.Windows.Forms.Label lblmadetai;
        private System.Windows.Forms.Label lbltendetai;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblTimKiem;
        private System.Windows.Forms.TextBox txtmadetai;
        private System.Windows.Forms.TextBox txttendetai;
        private System.Windows.Forms.TextBox txtmagv;
        private System.Windows.Forms.TextBox txttimkiem;
        private System.Windows.Forms.DataGridView dgvDeTai;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnTimKiem;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.Button btnThoat;
        private System.Drawing.Printing.PrintDocument printDocument1;
    }
}