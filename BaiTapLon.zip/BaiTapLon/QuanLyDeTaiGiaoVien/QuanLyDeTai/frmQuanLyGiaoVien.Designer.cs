﻿namespace QuanLyDeTai
{
    partial class frmQuanLyGiaoVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblqlgv = new System.Windows.Forms.Label();
            this.lblmagv = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbltengv = new System.Windows.Forms.Label();
            this.txttengv = new System.Windows.Forms.TextBox();
            this.txttrinhdo = new System.Windows.Forms.TextBox();
            this.txtmagv = new System.Windows.Forms.TextBox();
            this.dgvGiaoVien = new System.Windows.Forms.DataGridView();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnHuy = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnTimKiemID = new System.Windows.Forms.Button();
            this.lblTimKiem = new System.Windows.Forms.Label();
            this.txttimkiem = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGiaoVien)).BeginInit();
            this.SuspendLayout();
            // 
            // lblqlgv
            // 
            this.lblqlgv.AutoSize = true;
            this.lblqlgv.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblqlgv.Location = new System.Drawing.Point(356, 37);
            this.lblqlgv.Name = "lblqlgv";
            this.lblqlgv.Size = new System.Drawing.Size(309, 26);
            this.lblqlgv.TabIndex = 0;
            this.lblqlgv.Text = "QUẢN LÝ TÊN GIÁO VIÊN";
            // 
            // lblmagv
            // 
            this.lblmagv.AutoSize = true;
            this.lblmagv.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmagv.Location = new System.Drawing.Point(62, 108);
            this.lblmagv.Name = "lblmagv";
            this.lblmagv.Size = new System.Drawing.Size(117, 19);
            this.lblmagv.TabIndex = 1;
            this.lblmagv.Text = "Mã Giáo Viên:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(63, 227);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "Trình độ:";
            // 
            // lbltengv
            // 
            this.lbltengv.AutoSize = true;
            this.lbltengv.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltengv.Location = new System.Drawing.Point(59, 170);
            this.lbltengv.Name = "lbltengv";
            this.lbltengv.Size = new System.Drawing.Size(120, 19);
            this.lbltengv.TabIndex = 3;
            this.lbltengv.Text = "Tên Giáo Viên:";
            // 
            // txttengv
            // 
            this.txttengv.Location = new System.Drawing.Point(187, 169);
            this.txttengv.Name = "txttengv";
            this.txttengv.Size = new System.Drawing.Size(236, 22);
            this.txttengv.TabIndex = 4;
            // 
            // txttrinhdo
            // 
            this.txttrinhdo.Location = new System.Drawing.Point(187, 226);
            this.txttrinhdo.Name = "txttrinhdo";
            this.txttrinhdo.Size = new System.Drawing.Size(236, 22);
            this.txttrinhdo.TabIndex = 4;
            // 
            // txtmagv
            // 
            this.txtmagv.Location = new System.Drawing.Point(187, 105);
            this.txtmagv.Name = "txtmagv";
            this.txtmagv.Size = new System.Drawing.Size(236, 22);
            this.txtmagv.TabIndex = 4;
            // 
            // dgvGiaoVien
            // 
            this.dgvGiaoVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGiaoVien.Location = new System.Drawing.Point(464, 105);
            this.dgvGiaoVien.Name = "dgvGiaoVien";
            this.dgvGiaoVien.RowTemplate.Height = 24;
            this.dgvGiaoVien.Size = new System.Drawing.Size(449, 218);
            this.dgvGiaoVien.TabIndex = 5;
            // 
            // btnThem
            // 
            this.btnThem.Location = new System.Drawing.Point(187, 403);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(75, 42);
            this.btnThem.TabIndex = 6;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // btnSua
            // 
            this.btnSua.Location = new System.Drawing.Point(313, 403);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(75, 42);
            this.btnSua.TabIndex = 6;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.Location = new System.Drawing.Point(431, 403);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(75, 42);
            this.btnXoa.TabIndex = 6;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnLuu
            // 
            this.btnLuu.Location = new System.Drawing.Point(549, 403);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(75, 42);
            this.btnLuu.TabIndex = 6;
            this.btnLuu.Text = "Lưu";
            this.btnLuu.UseVisualStyleBackColor = true;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // btnHuy
            // 
            this.btnHuy.Location = new System.Drawing.Point(672, 403);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(75, 42);
            this.btnHuy.TabIndex = 6;
            this.btnHuy.Text = "Hủy";
            this.btnHuy.UseVisualStyleBackColor = true;
            // 
            // btnThoat
            // 
            this.btnThoat.Location = new System.Drawing.Point(797, 403);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(75, 42);
            this.btnThoat.TabIndex = 6;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // btnTimKiemID
            // 
            this.btnTimKiemID.Location = new System.Drawing.Point(66, 403);
            this.btnTimKiemID.Name = "btnTimKiemID";
            this.btnTimKiemID.Size = new System.Drawing.Size(92, 42);
            this.btnTimKiemID.TabIndex = 6;
            this.btnTimKiemID.Text = "Tìm Kiếm";
            this.btnTimKiemID.UseVisualStyleBackColor = true;
            this.btnTimKiemID.Click += new System.EventHandler(this.btnTimKiemID_Click);
            // 
            // lblTimKiem
            // 
            this.lblTimKiem.AutoSize = true;
            this.lblTimKiem.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimKiem.Location = new System.Drawing.Point(63, 305);
            this.lblTimKiem.Name = "lblTimKiem";
            this.lblTimKiem.Size = new System.Drawing.Size(89, 19);
            this.lblTimKiem.TabIndex = 7;
            this.lblTimKiem.Text = "Tìm Kiếm:";
            // 
            // txttimkiem
            // 
            this.txttimkiem.Location = new System.Drawing.Point(187, 302);
            this.txttimkiem.Name = "txttimkiem";
            this.txttimkiem.Size = new System.Drawing.Size(236, 22);
            this.txttimkiem.TabIndex = 8;
            // 
            // frmQuanLyGiaoVien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(962, 470);
            this.Controls.Add(this.txttimkiem);
            this.Controls.Add(this.lblTimKiem);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnHuy);
            this.Controls.Add(this.btnLuu);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnSua);
            this.Controls.Add(this.btnTimKiemID);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.dgvGiaoVien);
            this.Controls.Add(this.txttrinhdo);
            this.Controls.Add(this.txtmagv);
            this.Controls.Add(this.txttengv);
            this.Controls.Add(this.lbltengv);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblmagv);
            this.Controls.Add(this.lblqlgv);
            this.Name = "frmQuanLyGiaoVien";
            this.Text = "frmQuanLyGiaoVien";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmQuanLyGiaoVien_FormClosing);
            this.Load += new System.EventHandler(this.frmQuanLyGiaoVien_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGiaoVien)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblqlgv;
        private System.Windows.Forms.Label lblmagv;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbltengv;
        private System.Windows.Forms.TextBox txttengv;
        private System.Windows.Forms.TextBox txttrinhdo;
        private System.Windows.Forms.TextBox txtmagv;
        private System.Windows.Forms.DataGridView dgvGiaoVien;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnTimKiemID;
        private System.Windows.Forms.Label lblTimKiem;
        private System.Windows.Forms.TextBox txttimkiem;
    }
}