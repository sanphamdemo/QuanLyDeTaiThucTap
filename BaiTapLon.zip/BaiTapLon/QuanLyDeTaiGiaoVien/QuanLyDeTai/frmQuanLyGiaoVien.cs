﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace QuanLyDeTai
{
    public partial class frmQuanLyGiaoVien : Form
    {
        public frmQuanLyGiaoVien()
        {
            InitializeComponent();
        }
        SqlConnection connection;

        private void frmQuanLyGiaoVien_Load(object sender, EventArgs e)
        {
            string conString = ConfigurationManager.ConnectionStrings["QLDeTai"].ConnectionString.ToString();
            connection = new SqlConnection(conString);
            connection.Open();
            HienThi();
        }
        public void AddButton()
        {
            btnHuy.Enabled = false;
            btnLuu.Enabled = true;
            btnThoat.Enabled = true;
            btnThem.Enabled = true;
            btnTimKiemID.Enabled = false;
            btnSua.Enabled = true;
            btnXoa.Enabled = false;
            txttengv.Enabled = true;
            txtmagv.Enabled = true;
            txttrinhdo.Enabled = true;
            txttimkiem.Enabled = false;
        }
        public void FirstStatus()
        {
            btnHuy.Enabled = true;
            btnLuu.Enabled = true;
            btnThoat.Enabled = true;
            btnThem.Enabled = true;
            btnTimKiemID.Enabled = true;
            btnSua.Enabled = true;
            btnXoa.Enabled = true;
            txttengv.Enabled = false;
            txtmagv.Enabled = false;
            txttrinhdo.Enabled = false;
            txttimkiem.Enabled = false;
        }
        public void HienThi()
        {
            string sqlSelect = "SELECT * FROM tblGiaoVien";
            SqlCommand cmd = new SqlCommand(sqlSelect,connection);
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dgvGiaoVien.DataSource = dt;
            FirstStatus();
        }

        private void frmQuanLyGiaoVien_FormClosing(object sender, FormClosingEventArgs e)
        {
            connection.Close();
        }
        private void btnThem_Click(object sender, EventArgs e)
        {
            AddButton();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            string sqlUpdate = "UPDATE tblGiaoVien SET TenGV=@TenGV, Trinhdo=@Trinhdo WHERE MaGV=@MaGV";
            SqlCommand cmd = new SqlCommand(sqlUpdate, connection);
            cmd.Parameters.AddWithValue("MaGV", txtmagv.Text);
            cmd.Parameters.AddWithValue("TenGV", txttengv.Text);
            cmd.Parameters.AddWithValue("Trinhdo", txttrinhdo.Text);
            cmd.ExecuteNonQuery();
            HienThi();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            string sqlDelete = "DELETE FROM tblGiaoVien WHERE MaGV=@MaGV";
            SqlCommand cmd = new SqlCommand(sqlDelete, connection);
            cmd.Parameters.AddWithValue("MaGV", txtmagv.Text);
            cmd.Parameters.AddWithValue("TenGV", txttengv.Text);
            cmd.Parameters.AddWithValue("Trinhdo", txttrinhdo.Text);
            cmd.ExecuteNonQuery();
            HienThi();
        }

        private void btnTimKiemID_Click(object sender, EventArgs e)
        {
            string sqlSelectByID = "SELECT * FROM tblGiaoVien WHERE MaGV=@MaGV";
            SqlCommand cmd = new SqlCommand(sqlSelectByID, connection);
            cmd.Parameters.AddWithValue("MaGV", txttimkiem.Text);
            cmd.Parameters.AddWithValue("TenGV", txttengv.Text);
            cmd.Parameters.AddWithValue("Trinhdo", txttrinhdo.Text);
            cmd.ExecuteNonQuery();
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dgvGiaoVien.DataSource = dt;
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            string sqlInsert = "INSERT INTO tblGiaoVien VALUES (@MaGV, @TenGV, @Trinhdo)";
            SqlCommand cmd = new SqlCommand(sqlInsert, connection);
            cmd.Parameters.AddWithValue("MaGV", txtmagv.Text);
            cmd.Parameters.AddWithValue("TenGV", txttengv.Text);
            cmd.Parameters.AddWithValue("Trinhdo", txttrinhdo.Text);
            cmd.ExecuteNonQuery();
            HienThi();
        }
    }
}
