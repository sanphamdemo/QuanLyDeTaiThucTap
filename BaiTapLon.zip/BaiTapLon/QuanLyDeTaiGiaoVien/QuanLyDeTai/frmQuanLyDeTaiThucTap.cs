﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyDeTai
{
    public partial class frmQuanLyDeTaiThucTap : Form
    {
        public frmQuanLyDeTaiThucTap()
        {
            InitializeComponent();
        }

        private void btnGiaoVien_Click(object sender, EventArgs e)
        {
            frmQuanLyGiaoVien QuanLyGV = new frmQuanLyGiaoVien();
            QuanLyGV.Show();
        }

        private void btnDeTai_Click(object sender, EventArgs e)
        {
            frmQuanLyDeTai QuanLyDT = new frmQuanLyDeTai();
            QuanLyDT.Show();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
